import React, { useMemo, useRef, useState } from "react";
import { CalendarDays, ClipboardList, NotebookPen, Mail, PartyPopper, Users, Plus, FileText, Send, Download, Sparkles, CheckCircle2, XCircle } from "lucide-react";

/**
 * Campus Copilot — Single-file React MVP (UCR Colors + Resources)
 * ---------------------------------------------------------------
 * Tabs:
 *  - Calendar (paste syllabus text → parse → events → export .ics)
 *  - Group Projects (prompt → auto plan w/ roles & deadlines)
 *  - Notes (type notes + upload audio → mock transcript → flashcards)
 *  - Inbox (find prof/TA emails from syllabus; compose via Gmail/Apple)
 *  - Campus (events & freebies feed, simple filters)
 *  - Community (simple campus chat rooms)
 *  - Resources (UCR CAPS quick contacts & links)
 */

// ---------- Utilities ----------
const cls = (...s) => s.filter(Boolean).join(" ");

const SECTION = ({ title, icon, children, actions }) => (
  <section className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
    <header className="flex items-center justify-between mb-4">
      <h3 className="flex items-center gap-2 text-slate-800 font-semibold text-lg">
        {icon}
        {title}
      </h3>
      <div className="flex items-center gap-2">{actions}</div>
    </header>
    {children}
  </section>
);

const downloadFile = (filename, content, type = "text/plain") => {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
};

// Build a very simple ICS string (UTC all-day events)
const toICS = (events) => {
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Campus Copilot Demo//EN",
  ];
  const dt = (d) => {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}${mm}${dd}`;
  };
  events.forEach((e, i) => {
    const start = dt(e.date);
    const endDate = new Date(e.date);
    endDate.setDate(endDate.getDate() + 1);
    const end = dt(endDate);
    lines.push(
      "BEGIN:VEVENT",
      `UID:${i}-${Math.random().toString(36).slice(2)}@campus-copilot-demo`,
      `DTSTAMP:${dt(new Date())}T000000Z`,
      `DTSTART;VALUE=DATE:${start}`,
      `DTEND;VALUE=DATE:${end}`,
      `SUMMARY:${escapeICS(e.title)}`,
      `DESCRIPTION:${escapeICS(e.description || "")}`,
      "END:VEVENT"
    );
  });
  lines.push("END:VCALENDAR");
  return lines.join("\n");
};

const escapeICS = (s) => s.replace(/\\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");

// Date parsing helpers
const MONTHS = [
  "january","february","march","april","may","june",
  "july","august","september","october","november","december",
];

function parseDatesFromText(text, defaultYear = new Date().getFullYear()) {
  const lines = text.split(/\\n|\\r/).map((l) => l.trim()).filter(Boolean);
  const events = [];

  const monthNameRe = new RegExp(`\\b(${MONTHS.join("|")})\\b`, "i");
  const mmddRe = /\\b(\\d{1,2})\\/(\\d{1,2})(?:\\/(\\d{2,4}))?\\b/; // 9/1 or 9/1/25
  const isoRe = /\\b(\\d{4})-(\\d{2})-(\\d{2})\\b/; // 2025-10-02
  const monthNameDayRe = new RegExp(
    `\\b(${MONTHS.join("|")})\\s+(\\d{1,2})(?:,\\s*(\\d{4}))?`,
    "i"
  );

  const typeFromLine = (l) => {
    const lo = l.toLowerCase();
    if (/(midterm|final)/i.test(lo)) return "Exam";
    if (/(quiz)/i.test(lo)) return "Quiz";
    if (/(homework|assignment|problem set|pset|hw)/i.test(lo)) return "Homework";
    if (/(project|milestone|deliverable)/i.test(lo)) return "Project";
    return "Class Event";
  };

  for (const l of lines) {
    let date = null;
    let title = l.replace(/\\s+/g, " ").trim();

    if (isoRe.test(l)) {
      const [, Y, M, D] = l.match(isoRe);
      date = new Date(Number(Y), Number(M) - 1, Number(D));
    } else if (mmddRe.test(l)) {
      const [, m, d, y] = l.match(mmddRe);
      const year = y ? normalizeYear(y) : defaultYear;
      date = new Date(year, Number(m) - 1, Number(d));
    } else if (monthNameDayRe.test(l)) {
      const [, name, d, y] = l.match(monthNameDayRe);
      const mIdx = MONTHS.indexOf(name.toLowerCase());
      const year = y ? Number(y) : defaultYear;
      if (mIdx >= 0) date = new Date(year, mIdx, Number(d));
    } else if (monthNameRe.test(l)) {
      // Month mentioned but no day → skip
    }

    if (date && !isNaN(date.getTime())) {
      events.push({
        date,
        title: `${typeFromLine(l)} — ${cleanTitle(title)}`,
        description: l,
      });
    }
  }

  const key = (e) => `${e.date.toDateString()}|${e.title}`;
  const map = new Map();
  events.forEach((e) => map.set(key(e), e));
  return Array.from(map.values()).sort((a, b) => a.date - b.date);
}

function normalizeYear(y) {
  const n = Number(y);
  if (n < 100) return 2000 + n; // '25' => 2025
  return n;
}

function cleanTitle(s) {
  return s
    .replace(/\\b(due|by|on)\\b/gi, "")
    .replace(/\\s+/g, " ")
    .trim();
}

// Mock LLM generators (replace with API calls in production)
const mockTasks = (prompt, group, dueDate) => {
  const base = [
    { title: "Outline & Sources", daysBefore: 10 },
    { title: "Draft Slides", daysBefore: 6 },
    { title: "First Rehearsal", daysBefore: 4 },
    { title: "Polish & QA", daysBefore: 2 },
  ];
  const names = group.map((g) => g.name).filter(Boolean);
  const dd = dueDate || addDays(new Date(), 14);
  return base.map((t, i) => ({
    id: `${i}-${t.title}`,
    title: t.title,
    assignee: names[i % Math.max(1, names.length)] || "Unassigned",
    deadline: addDays(dd, -t.daysBefore),
    status: i === 0 ? "In Progress" : "Pending",
  }));
};

const addDays = (d, n) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};

const fmt = (d) => d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });

// ---------- Main App ----------
export default function App() {
  // Lift syllabus text to app so Inbox can read it
  const [syllabusText, setSyllabusText] = useState(ExampleSyllabus.trim());
  const [active, setActive] = useState("calendar");

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <TopNav />
      <div className="max-w-7xl mx-auto grid grid-cols-12 gap-5 px-4 pb-10">
        <Sidebar active={active} setActive={setActive} />
        <main className="col-span-12 lg:col-span-9 xl:col-span-10">
          {active === "calendar" && <CalendarTab syllabusText={syllabusText} setSyllabusText={setSyllabusText} />}
          {active === "projects" && <ProjectsTab />}
          {active === "notes" && <NotesTab />}
          {active === "inbox" && <InboxTab syllabusText={syllabusText} />}
          {active === "campus" && <CampusTab />}
          {active === "community" && <CommunityTab />}
          {active === "resources" && <ResourcesTab />}
        </main>
      </div>
    </div>
  );
}

function TopNav() {
  return (
    <div className="sticky top-0 z-10 bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60 border-b border-slate-200">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <Sparkles className="w-5 h-5 text-indigo-600" />
          <span className="font-semibold tracking-tight">Campus Copilot</span>
          <span className="text-xs bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full">Demo</span>
        </div>
        <div className="text-xs text-slate-500">All-in-one student OS</div>
      </div>
    </div>
  );
}

function Sidebar({ active, setActive }) {
  const items = [
    { id: "calendar", label: "Calendar", icon: <CalendarDays className="w-4 h-4" /> },
    { id: "projects", label: "Group Projects", icon: <ClipboardList className="w-4 h-4" /> },
    { id: "notes", label: "Notes", icon: <NotebookPen className="w-4 h-4" /> },
    { id: "inbox", label: "Inbox", icon: <Mail className="w-4 h-4" /> },
    { id: "campus", label: "Campus", icon: <PartyPopper className="w-4 h-4" /> },
    { id: "community", label: "Community", icon: <Users className="w-4 h-4" /> },
    { id: "resources", label: "Resources", icon: <FileText className="w-4 h-4" /> },
  ];
  return (
    <aside className="hidden lg:block col-span-3 xl:col-span-2">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-2">
        {items.map((it) => (
          <button
            key={it.id}
            onClick={() => setActive(it.id)}
            className={cls(
              "w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition",
              active === it.id
                ? "bg-indigo-50 text-indigo-700"
                : "hover:bg-slate-50 text-slate-700"
            )}
          >
            {it.icon}
            {it.label}
          </button>
        ))}
      </div>
    </aside>
  );
}

// ---------- Calendar Tab ----------
function CalendarTab({ syllabusText, setSyllabusText }) {
  const [course, setCourse] = useState("ECON 102");
  const events = useMemo(() => parseDatesFromText(syllabusText), [syllabusText]);

  const onUpload = async (file) => {
    if (!file) return;
    if (file.type === "text/plain") {
      const text = await file.text();
      setSyllabusText(text);
    } else {
      alert("For the demo, upload a .txt syllabus or paste text. (PDF parsing can be added with pdfjs.)");
    }
  };

  const exportICS = () => {
    const ics = toICS(
      events.map((e) => ({ ...e, title: `${course}: ${e.title}` }))
    );
    downloadFile(`${course.replace(/\s+/g, "_")}-syllabus.ics`, ics, "text/calendar");
  };

  return (
    <div className="grid gap-5">
      <SECTION
        title="Syllabus → Calendar"
        icon={<CalendarDays className="w-5 h-5 text-indigo-600" />}
        actions={
          <button
            onClick={exportICS}
            className="inline-flex items-center gap-2 text-sm bg-indigo-600 text-white px-3 py-1.5 rounded-xl hover:bg-indigo-700"
          >
            <Download className="w-4 h-4" /> Export .ics
          </button>
        }
      >
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-1 space-y-3">
            <label className="text-xs font-medium text-slate-600">Course</label>
            <input
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />

            <label className="text-xs font-medium text-slate-600">Upload syllabus (.txt) or paste below</label>
            <div className="flex items-center gap-2">
              <input
                id="syllfile"
                type="file"
                accept=".txt"
                onChange={(e) => onUpload(e.target.files?.[0])}
                className="block w-full text-sm"
              />
            </div>
            <textarea
              value={syllabusText}
              onChange={(e) => setSyllabusText(e.target.value)}
              rows={18}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
            <p className="text-xs text-slate-500">Parsing dates & types (Exam, Quiz, Homework, Project). Export an .ics and import to Google/Apple Calendar.</p>
          </div>

          <div className="lg:col-span-2">
            <div className="grid gap-3">
              <h4 className="font-semibold">Detected Events ({events.length})</h4>
              <div className="grid md:grid-cols-2 gap-3">
                {events.length === 0 && (
                  <div className="text-sm text-slate-500">No dates found yet — try adding lines like "Oct 2 Midterm" or "09/14 Homework 1 due".</div>
                )}
                {events.map((e, i) => (
                  <div key={i} className="border border-slate-200 rounded-xl p-3 flex items-start gap-3">
                    <div className="shrink-0 text-center">
                      <div className="text-xs uppercase text-slate-500">{e.date.toLocaleString(undefined, { month: "short" })}</div>
                      <div className="text-2xl font-bold -mt-1">{e.date.getDate()}</div>
                    </div>
                    <div className="grow">
                      <div className="font-medium">{e.title}</div>
                      <div className="text-xs text-slate-500">{e.description}</div>
                    </div>
                    <div className="shrink-0">
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">All-day</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </SECTION>

      <SECTION
        title="Smart Study Suggestions"
        icon={<Sparkles className="w-5 h-5 text-indigo-600" />}
      >
        <p className="text-sm text-slate-600">(Demo) Based on upcoming deadlines, here are suggested 30–60 minute blocks this week.</p>
        <div className="mt-3 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {events.slice(0, 6).map((e, i) => (
            <div key={i} className="border border-slate-200 rounded-xl p-3">
              <div className="text-xs text-slate-500">For: {e.title.split(" — ")[0]}</div>
              <div className="font-medium">Study on {fmt(addDays(e.date, -2))}</div>
              <div className="text-xs text-slate-500">Focus: {e.title.split(" — ")[1] || "Upcoming item"}</div>
            </div>
          ))}
        </div>
      </SECTION>
    </div>
  );
}

// ---------- Projects Tab ----------
function ProjectsTab() {
  const [prompt, setPrompt] = useState("Design a 10-minute presentation on behavioral economics applications. Due Oct 21, 2025. 4 teammates.");
  const [group, setGroup] = useState([
    { name: "Faith", hours: 4 },
    { name: "Nick", hours: 3 },
    { name: "Emi", hours: 2 },
    { name: "Josh", hours: 3 },
  ]);
  const due = extractDueDate(prompt);
  const tasks = useMemo(() => mockTasks(prompt, group, due), [prompt, group, due]);

  return (
    <div className="grid gap-5">
      <SECTION title="Group Project Auto-Manager" icon={<ClipboardList className="w-5 h-5 text-indigo-600" />}>
        <div className="grid lg:grid-cols-3 gap-5">
          <div className="lg:col-span-1 space-y-3">
            <label className="text-xs font-medium text-slate-600">Assignment Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={10}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-400"
            />

            <label className="text-xs font-medium text-slate-600">Team & Availability (hrs/week)</label>
            <div className="space-y-2">
              {group.map((m, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input
                    value={m.name}
                    onChange={(e) => updateGroup(setGroup, i, { name: e.target.value })}
                    className="w-36 px-3 py-2 rounded-xl border border-slate-300"
                  />
                  <input
                    type="range"
                    min={0}
                    max={10}
                    value={m.hours}
                    onChange={(e) => updateGroup(setGroup, i, { hours: Number(e.target.value) })}
                    className="w-40"
                  />
                  <span className="text-xs text-slate-600 w-8">{m.hours}</span>
                </div>
              ))}
              <button
                onClick={() => setGroup((g) => [...g, { name: "", hours: 2 }])}
                className="inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-50"
              >
                <Plus className="w-4 h-4" /> Add teammate
              </button>
            </div>
            <p className="text-xs text-slate-500">In production, the AI would map tasks ↔ strengths and push deadlines to each member's calendar.</p>
          </div>

          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-500">Due Date</div>
                <div className="font-semibold">{due ? fmt(due) : "Not detected — add 'Due Oct 21, 2025' to prompt"}</div>
              </div>
              <button
                onClick={() => downloadFile("project-plan.json", JSON.stringify({ prompt, group, tasks }, null, 2), "application/json")}
                className="inline-flex items-center gap-2 text-sm bg-indigo-600 text-white px-3 py-1.5 rounded-xl hover:bg-indigo-700"
              >
                <Download className="w-4 h-4" /> Export Plan
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-3">
              {tasks.map((t) => (
                <div key={t.id} className="border border-slate-200 rounded-xl p-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-medium">{t.title}</div>
                      <div className="text-xs text-slate-500">Owner: {t.assignee || "TBD"}</div>
                    </div>
                    <span className={cls(
                      "text-[10px] px-2 py-0.5 rounded-full",
                      t.status === "In Progress" ? "bg-amber-50 text-amber-700" : "bg-slate-100 text-slate-600"
                    )}>{t.status}</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-1">Deadline: {fmt(t.deadline)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </SECTION>
    </div>
  );
}

function updateGroup(setGroup, i, patch) {
  setGroup((g) => g.map((m, idx) => (idx === i ? { ...m, ...patch } : m)));
}

function extractDueDate(text) {
  const iso = text.match(/(\\d{4})-(\\d{2})-(\\d{2})/);
  if (iso) return new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
  const monthName = new RegExp(`\\b(${MONTHS.join("|")})\\s+(\\d{1,2})(?:,\\s*(\\d{4}))?`, "i");
  const m = text.match(monthName);
  if (m) {
    const year = m[3] ? Number(m[3]) : new Date().getFullYear();
    const idx = MONTHS.indexOf(m[1].toLowerCase());
    return new Date(year, idx, Number(m[2]));
  }
  const slash = text.match(/(\\d{1,2})\\/(\\d{1,2})(?:\\/(\\d{2,4}))?/);
  if (slash) {
    const year = slash[3] ? normalizeYear(slash[3]) : new Date().getFullYear();
    return new Date(year, Number(slash[1]) - 1, Number(slash[2]));
  }
  return null;
}

// ---------- Notes Tab ----------
function NotesTab() {
  const [note, setNote] = useState("");
  const [transcript, setTranscript] = useState("");
  const [flashcards, setFlashcards] = useState([]);

  const audioRef = useRef(null);

  const onAudioUpload = async (file) => {
    if (!file) return;
    setTranscript(`(demo transcript) Today we discussed supply and demand curves, price elasticity, and a case study about coffee markets. Key terms: equilibrium, surplus, shortage, elasticity.`);
  };

  const generateFlashcards = () => {
    const seeds = [
      { q: "Define equilibrium.", a: "The price where quantity supplied equals quantity demanded." },
      { q: "What is price elasticity?", a: "A measure of how quantity demanded responds to price changes." },
      { q: "Surplus vs. shortage?", a: "Surplus: supply > demand. Shortage: demand > supply." },
    ];
    setFlashcards(seeds);
  };

  return (
    <div className="grid gap-5">
      <SECTION title="Notes & Recordings" icon={<NotebookPen className="w-5 h-5 text-indigo-600" />}>
        <div className="grid lg:grid-cols-3 gap-5">
          <div className="lg:col-span-1 space-y-3">
            <label className="text-xs font-medium text-slate-600">Write Notes</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={12}
              placeholder="Type your class notes here..."
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-400"
            />
            <div className="flex gap-2">
              <button
                onClick={() => downloadFile("notes.txt", note || "")}
                className="inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-50"
              >
                <Download className="w-4 h-4" /> Export Notes
              </button>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-3">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">Upload Lecture Audio (demo)</label>
              <input
                type="file"
                accept="audio/*"
                ref={audioRef}
                onChange={(e) => onAudioUpload(e.target.files?.[0])}
                className="block w-full text-sm"
              />
              <p className="text-xs text-slate-500">In production, send audio → ASR API → transcript → summarize.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-3">
              <div className="border border-slate-200 rounded-xl p-3">
                <div className="font-medium mb-1">Transcript</div>
                <div className="text-sm whitespace-pre-wrap text-slate-700 min-h-[120px]">{transcript || "(Upload audio to transcribe)"}</div>
              </div>
              <div className="border border-slate-200 rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium">Flashcards</div>
                  <button
                    onClick={generateFlashcards}
                    className="inline-flex items-center gap-2 text-xs bg-indigo-600 text-white px-2.5 py-1 rounded-lg hover:bg-indigo-700"
                  >
                    <Sparkles className="w-3.5 h-3.5" /> Generate
                  </button>
                </div>
                {flashcards.length === 0 ? (
                  <div className="text-sm text-slate-500">(Generate from transcript)</div>
                ) : (
                  <ul className="space-y-2">
                    {flashcards.map((fc, i) => (
                      <li key={i} className="border border-slate-200 rounded-lg p-2">
                        <div className="text-xs text-slate-500">Q</div>
                        <div className="text-sm font-medium">{fc.q}</div>
                        <div className="text-xs text-slate-500 mt-1">A: {fc.a}</div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
      </SECTION>
    </div>
  );
}

// ---------- Inbox Tab (syllabus contacts → compose) ----------
function InboxTab({ syllabusText }) {
  const [draft, setDraft] = useState("");
  const [showCompose, setShowCompose] = useState(false);
  const [selected, setSelected] = useState([]);

  // extract unique emails from the syllabus text
  const emails = useMemo(() => {
    if (!syllabusText) return [];
    const reg = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}/gi;
    const matches = syllabusText.match(reg) || [];
    const uniq = Array.from(new Set(matches.map((m) => m.toLowerCase())));
    // heuristic: sort prof/ta first if labeled in the line
    const lines = syllabusText.split(/\\n|\\r/);
    const score = (email) => {
      const line = lines.find((l) => l.toLowerCase().includes(email));
      if (!line) return 0;
      let s = 0;
      if (/prof|instructor/i.test(line)) s += 2;
      if (/ta|gsi|assistant/i.test(line)) s += 1;
      return s;
    };
    return uniq.sort((a, b) => score(b) - score(a));
  }, [syllabusText]);

  const toggle = (email) => {
    setSelected((prev) => (prev.includes(email) ? prev.filter((e) => e !== email) : [...prev, email]));
  };

  const openGmail = () => {
    const url = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(selected.join(","))}`;
    window.open(url, "_blank");
  };
  const openApple = () => {
    const url = `mailto:${selected.join(",")}`;
    window.location.href = url;
  };

  return (
    <div className="grid gap-5">
      <SECTION title="Student Inbox (Syllabus Contacts)" icon={<Mail className="w-5 h-5 text-indigo-600" />}>
        <p className="text-sm text-slate-600 mb-3">We scanned your uploaded syllabus and found these emails. Select the contacts and tap a provider to compose.</p>

        {emails.length === 0 ? (
          <div className="text-sm text-slate-500">No emails detected yet — paste or upload your syllabus in the Calendar tab.</div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {emails.map((em) => (
              <button
                key={em}
                onClick={() => toggle(em)}
                className={cls(
                  "text-left border rounded-xl px-3 py-2 text-sm",
                  selected.includes(em) ? "border-indigo-400 bg-indigo-50" : "border-slate-200 hover:bg-slate-50"
                )}
              >
                <div className="font-medium break-all">{em}</div>
                <div className="text-[11px] text-slate-500">{selected.includes(em) ? "Selected" : "Tap to select"}</div>
              </button>
            ))}
          </div>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            disabled={selected.length === 0}
            onClick={() => setShowCompose(true)}
            className={cls(
              "inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-xl",
              selected.length === 0 ? "bg-slate-100 text-slate-400 cursor-not-allowed" : "bg-indigo-600 text-white hover:bg-indigo-700"
            )}
          >
            <Send className="w-4 h-4" /> Compose
          </button>
          {selected.length > 0 && (
            <div className="text-xs text-slate-500">{selected.length} selected</div>
          )}
        </div>

        {/* Bottom sheet "pull-up" */}
        {showCompose && (
          <div className="fixed inset-0 z-50">
            <div className="absolute inset-0 bg-black/30" onClick={() => setShowCompose(false)} />
            <div className="absolute left-0 right-0 bottom-0 bg-white rounded-t-2xl shadow-2xl border border-slate-200 p-5">
              <div className="mx-auto max-w-3xl">
                <div className="flex items-center justify-between">
                  <div className="font-semibold">Compose with…</div>
                  <button onClick={() => setShowCompose(false)} className="text-slate-500 text-sm">Close</button>
                </div>
                <div className="mt-3 flex flex-wrap gap-3">
                  <button onClick={openGmail} className="inline-flex items-center gap-2 text-sm bg-red-600 text-white px-3 py-2 rounded-xl hover:opacity-90">
                    <Mail className="w-4 h-4" /> Gmail
                  </button>
                  <button onClick={openApple} className="inline-flex items-center gap-2 text-sm bg-slate-800 text-white px-3 py-2 rounded-xl hover:opacity-90">
                    <Mail className="w-4 h-4" /> Apple Mail
                  </button>
                </div>
                <div className="mt-4">
                  <div className="text-xs text-slate-500 mb-1">To:</div>
                  <div className="flex flex-wrap gap-1">
                    {selected.map((em) => (
                      <span key={em} className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full break-all">{em}</span>
                    ))}
                  </div>
                </div>
                <div className="mt-4">
                  <label className="text-xs text-slate-500">Quick draft (optional)</label>
                  <textarea
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder="Hello Professor, ..."
                    rows={4}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">(For demo, the draft isn’t auto-inserted; pick a provider above to open a compose window with recipients pre-filled.)</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </SECTION>
    </div>
  );
}

// ---------- Campus Tab ----------
function CampusTab() {
  const [filterFree, setFilterFree] = useState(true);
  const [events, setEvents] = useState(ExampleCampusEvents);

  const view = events.filter((e) => (filterFree ? e.free : true));

  return (
    <div className="grid gap-5">
      <SECTION title="Campus Life & Freebies" icon={<PartyPopper className="w-5 h-5 text-indigo-600" />}>
        <div className="flex items-center gap-3 mb-3">
          <label className="inline-flex items-center gap-2 text-sm">
            <input type="checkbox" checked={filterFree} onChange={(e) => setFilterFree(e.target.checked)} />
            Show only free food/freebies
          </label>
          <button
            onClick={() => setEvents((ev) => [{ title: "Pop-up Donuts", time: "Today 3pm", where: "Quad", free: true }, ...ev])}
            className="ml-auto inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-50"
          >
            <Plus className="w-4 h-4" /> Add event
          </button>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
          {view.map((e, i) => (
            <div key={i} className="border border-slate-200 rounded-xl p-3">
              <div className="font-medium">{e.title}</div>
              <div className="text-xs text-slate-500">{e.time} • {e.where}</div>
              <div className="mt-1">
                {e.free ? (
                  <span className="text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Free food/freebies
                  </span>
                ) : (
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                    <XCircle className="w-3 h-3" /> Not free
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-3">In production, scrape campus calendars + IG stories from student orgs, dedupe, personalize by location/time-between-classes.</p>
      </SECTION>
    </div>
  );
}

// ---------- Community Tab ----------
function CommunityTab() {
  const [room, setRoom] = useState("econ-102");
  const [msg, setMsg] = useState("");
  const [messages, setMessages] = useState([
    { room: "econ-102", user: "Faith", text: "Anyone down for a review session tonight?", ts: new Date() },
    { room: "econ-102", user: "Nick", text: "I can do 7pm at the library.", ts: new Date() },
  ]);

  const post = () => {
    if (!msg.trim()) return;
    setMessages((m) => [...m, { room, user: "You", text: msg.trim(), ts: new Date() }]);
    setMsg("");
  };

  const view = messages.filter((m) => m.room === room);

  return (
    <div className="grid gap-5">
      <SECTION title="Community" icon={<Users className="w-5 h-5 text-indigo-600" />}>
        <div className="flex items-center gap-3 mb-3">
          <select
            value={room}
            onChange={(e) => setRoom(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-300"
          >
            <option value="econ-102">#econ-102</option>
            <option value="cs-61a">#cs-61a</option>
            <option value="clubs">#clubs</option>
            <option value="events">#events</option>
          </select>
          <input
            value={msg}
            onChange={(e) => setMsg(e.target.value)}
            placeholder="Say something nice…"
            className="flex-1 px-3 py-2 rounded-xl border border-slate-300"
          />
          <button onClick={post} className="inline-flex items-center gap-2 text-sm bg-indigo-600 text-white px-3 py-2 rounded-xl hover:bg-indigo-700">
            <Send className="w-4 h-4" /> Send
          </button>
        </div>
        <div className="space-y-2">
          {view.map((m, i) => (
            <div key={i} className="border border-slate-200 rounded-xl p-3">
              <div className="text-xs text-slate-500">{m.user} • {m.ts.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
              <div className="text-sm">{m.text}</div>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-3">In production, rooms would be scoped per school and class roster; add mod tools & lightweight verification.</p>
      </SECTION>
    </div>
  );
}

// ---------- Resources Tab (UCR CAPS) ----------
function ResourcesTab() {
  const CAPS = {
    phone: "(951) 827-5531",
    crisisLabel: "Option 1 (24/7 Crisis Counselor)",
    deskLabel: "Option 2 (Front Desk, business hours)",
    ucrTalk: "(951) UCR-TALK (827-8255)",
    hours: "Mon, Tue, Wed, Fri: 8am–5pm • Thu: 9am–5pm",
    email: "counseling@ucr.edu",
    address: "Student Health & Counseling Center, 388 W. Linden St., Riverside, CA 92521",
    website: "https://counseling.ucr.edu/",
    emailPolicy: "Email is not for confidential counseling. Call for urgent needs.",
  };

  const tel = (n) => `tel:${n.replace(/[^\\d+]/g, "")}`;

  return (
    <div className="grid gap-5">
      <SECTION title="UCR CAPS — Counseling & Psychological Services" icon={<FileText className="w-5 h-5 text-indigo-600" />}>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="text-sm">If you or a friend needs support, you can reach CAPS directly:</div>
            <div className="flex flex-col gap-2">
              <a href={tel(CAPS.phone)} className="inline-flex items-center justify-between border rounded-xl px-3 py-2 hover:bg-slate-50">
                <div>
                  <div className="font-medium">Call {CAPS.phone}</div>
                  <div className="text-xs text-slate-500">Tap and then choose {CAPS.crisisLabel} or {CAPS.deskLabel}</div>
                </div>
                <span className="text-[10px] bg-indigo-50 px-2 py-0.5 rounded-full">Phone</span>
              </a>
              <a href={tel(CAPS.ucrTalk)} className="inline-flex items-center justify-between border rounded-xl px-3 py-2 hover:bg-slate-50">
                <div>
                  <div className="font-medium">Call {CAPS.ucrTalk}</div>
                  <div className="text-xs text-slate-500">24/7 Crisis line</div>
                </div>
                <span className="text-[10px] bg-indigo-50 px-2 py-0.5 rounded-full">Crisis</span>
              </a>
              <a href={`mailto:${CAPS.email}`} className="inline-flex items-center justify-between border rounded-xl px-3 py-2 hover:bg-slate-50">
                <div>
                  <div className="font-medium">Email {CAPS.email}</div>
                  <div className="text-xs text-slate-500">{CAPS.emailPolicy}</div>
                </div>
                <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">Email</span>
              </a>
            </div>
            <div className="text-xs text-slate-500">Hours: {CAPS.hours}</div>
            <div className="text-xs text-slate-500">Address: {CAPS.address} — <a className="underline" target="_blank" href={`https://maps.google.com/?q=${encodeURIComponent(CAPS.address)}`}>Open map</a></div>
            <div className="text-xs text-slate-500">Website: <a className="underline" target="_blank" href={CAPS.website}>{CAPS.website}</a></div>
          </div>

          <div className="space-y-3">
            <div className="font-medium">Other UCR Support</div>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li><a className="underline" target="_blank" href="https://studentwellness.ucr.edu/">Health, Well-being & Safety hub</a></li>
              <li><a className="underline" target="_blank" href="https://counseling.ucr.edu/resources-support-specialty-care-self-help-and-making-connections">Self-help & specialty care resources</a></li>
              <li><a className="underline" target="_blank" href="https://counseling.ucr.edu/urgent-services-contacts">Urgent services & contacts</a></li>
              <li><a className="underline" target="_blank" href="https://counseling.ucr.edu/email-policy">CAPS email policy</a></li>
            </ul>
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
              <strong>Emergency:</strong> Call 911 or UCR Police (on campus): (951) 827-5222.
            </div>
          </div>
        </div>
      </SECTION>
    </div>
  );
}

// ---------- Example Data ----------
const ExampleSyllabus = `
Instructor: Prof. Hannah Lee (hlee@university.edu)
TA: Marcus King (mking@university.edu)
Office: 2-113, Tu/Th 3–5pm
Aug 28 — First lecture
Sep 6 — Homework 1 due
September 20 — Quiz 1 (Ch 1-3)
10/02 — Midterm 1
October 21 — Project Milestone
Nov 14 — Homework 2 due
2025-12-10 — Final Exam
`;

const ExampleCampusEvents = [
  { title: "CS Club Hack Night", time: "Thu 7pm", where: "Lab 201", free: true },
  { title: "Career Fair", time: "Fri 11am", where: "Main Hall", free: false },
  { title: "Campus Market Samples", time: "Today 1pm", where: "Quad", free: true },
];
