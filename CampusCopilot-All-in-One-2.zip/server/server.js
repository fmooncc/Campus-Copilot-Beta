import express from 'express'
import cors from 'cors'

const app = express()
app.use(cors())
app.use(express.json())

app.get('/api/health', (req, res) => res.json({ ok: true }))

const MONTHS = ["january","february","march","april","may","june","july","august","september","october","november","december"]
function normalizeYear(y){ const n=Number(y); return n<100?2000+n:n }
function parseDatesFromText(text, defaultYear = new Date().getFullYear()) {
  const lines = text.split(/\n|\r/).map(l=>l.trim()).filter(Boolean);
  const events = [];
  const monthNameRe = new RegExp(`\\b(${MONTHS.join('|')})\\b`, 'i');
  const mmddRe = /\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/;
  const isoRe = /\b(\d{4})-(\d{2})-(\d{2})\b/;
  const monthNameDayRe = new RegExp(`\\b(${MONTHS.join('|')})\\s+(\\d{1,2})(?:,\\s*(\\d{4}))?`,'i');

  const typeFromLine = (l) => {
    const lo = l.toLowerCase();
    if (/(midterm|final)/i.test(lo)) return 'Exam';
    if (/(quiz)/i.test(lo)) return 'Quiz';
    if (/(homework|assignment|problem set|pset|hw)/i.test(lo)) return 'Homework';
    if (/(project|milestone|deliverable)/i.test(lo)) return 'Project';
    return 'Class Event';
  };

  for (const l of lines) {
    let date = null;
    if (isoRe.test(l)) {
      const [, Y, M, D] = l.match(isoRe);
      date = new Date(Number(Y), Number(M) - 1, Number(D));
    } else if (mmddRe.test(l)) {
      const [, m, d, y] = l.match(mmddRe);
      const year = y ? normalizeYear(y) : defaultYear;
      date = new Date(year, Number(m) - 1, Number(d));
    } else if (monthNameDayRe.test(l)) {
      const [, name, d, y] = l.match(monthNameDayRe);
      const mIdx = MONTHS.indexOf(name.toLowerCase());
      const year = y ? Number(y) : defaultYear;
      if (mIdx >= 0) date = new Date(year, mIdx, Number(d));
    }
    if (date && !isNaN(date.getTime())) {
      events.push({ date, title: `${typeFromLine(l)} — ${l}`, description: l });
    }
  }
  return events.sort((a,b)=>a.date-b.date);
}

app.post('/api/parse-syllabus', (req, res) => {
  const text = req.body?.text || '';
  const events = parseDatesFromText(text);
  res.json({ events });
})

app.post('/api/transcribe', (req, res) => {
  const summary = 'Demo summary from server: lecture covered elasticity and coffee market case.';
  const flashcards = [
    { q: 'Define equilibrium.', a: 'Price where quantity supplied equals quantity demanded.' },
    { q: 'Price elasticity?', a: 'Responsiveness of demand to price changes.' },
  ];
  res.json({ summary, flashcards });
})

app.get('/api/events', (req, res) => {
  res.json([
    { title: 'UCR Career Fair', time: 'Fri 11am', where: 'SRC North', free: false },
    { title: 'ASUCR Free Pizza', time: 'Wed 2pm', where: 'Hub Plaza', free: true },
  ]);
})

app.get('/api/caps', (req, res) => {
  res.json({
    phone: '(951) 827-5531',
    crisis: '(951) UCR-TALK (827-8255)',
    email: 'counseling@ucr.edu',
    website: 'https://counseling.ucr.edu/'
  })
})

const PORT = process.env.PORT || 8787
app.listen(PORT, () => console.log('API server listening on :' + PORT))
